import requests
from twilio.twiml.voice_response import VoiceResponse
from twilio.rest import Client
from flask import Flask, request, Response

app = Flask(__name__)

# Twilio credentials
account_sid = 'ACf8dd7b91e7be84ba31a4ca78b688f815'
auth_token = '3110d6719b874ac2384f1aaabfd31172'
twilio_phone_number = '+12764444987'
flask_api_endpoint = 'http://130.211.112.219:8080/chat'  # Your Flask API endpoint


# Function to make outbound call
def make_outbound_call(to_number):
    client = Client(account_sid, auth_token)

    call = client.calls.create(
        url=request.host_url + 'response',
        to=to_number,
        from_=twilio_phone_number,
        method='POST'
    )

    print(call.sid)  # Print the call SID for reference


# Twilio webhook endpoint for initiating the call and handling user input
@app.route('/response', methods=['POST'])
def response():
    if 'SpeechResult' in request.values:
        user_voice_input = request.values.get('SpeechResult', '')
        flask_response = process_speech(user_voice_input)

        twiml_response = VoiceResponse()
        twiml_response.say(flask_response, voice='alice')

        return str(twiml_response)

    else:
        twiml_response = VoiceResponse()
        twiml_response.say("Hmm... Sorry, something went wrong.", voice='alice')

        return str(twiml_response)


# Function to process speech input
def process_speech(user_voice_input):
    response = requests.post(flask_api_endpoint, json={'message': user_voice_input})
    if response.status_code == 200:
        return response.json().get('response', 'Hmm... Sorry, something went wrong.')
    else:
        print(f"Failed to get response from Flask API: {response.text}")
        return "Hmm... Sorry, something went wrong."


# Example usage
if __name__ == '__main__':
    # Replace 'to_number' with the recipient's phone number
    to_number = '+14234569059'  # Example phone number

    make_outbound_call(to_number)
