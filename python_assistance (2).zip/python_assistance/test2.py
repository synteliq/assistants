from flask import Flask, request, jsonify
import psycopg2

app = Flask(__name__)

# PostgreSQL database configuration
DB_NAME = "aiworld"
DB_USER = "mobiledevarkatiss"
DB_PASSWORD = "test123"
DB_HOST = "localhost"
DB_PORT = "5432"

# Database connection
def connect_to_db():
    conn = psycopg2.connect(
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        host=DB_HOST,
        port=DB_PORT
    )
    return conn

# User registration endpoint
# User registration endpoint
@app.route('/register', methods=['POST'])
def register_user():
    try:
        conn = connect_to_db()
        cur = conn.cursor()

        # Extracting data from request
        data = request.get_json()
        email_or_phone = data.get('email_or_phone')
        companion_name = data.get('companion_name')
        username = data.get('username')

        # Check if the username or email/phone already exists
        cur.execute("SELECT username FROM users WHERE username = %s", (username,))
        existing_username = cur.fetchone()
        cur.execute("SELECT email_or_phone FROM users WHERE email_or_phone = %s", (email_or_phone,))
        existing_email_or_phone = cur.fetchone()

        if existing_username or existing_email_or_phone:
            response = {'error': 'Username or email/phone already exists'}
            return jsonify(response), 400

        # Inserting user data into the database
        cur.execute("INSERT INTO users (email_or_phone, companion_name, username) VALUES (%s, %s, %s)",
                    (email_or_phone, companion_name, username))
        conn.commit()

        cur.close()
        conn.close()

        response = {'message': 'User registered successfully'}
        return jsonify(response), 201

    except Exception as e:
        response = {'error': str(e)}
        return jsonify(response), 500


# GET endpoint for fetching user information
# POST endpoint for searching users by any field
# POST endpoint for searching users by any field
# POST endpoint for searching users by any field
@app.route('/search_users', methods=['POST'])
def search_users():
    try:
        conn = connect_to_db()
        cur = conn.cursor()

        # Extracting data from request
        data = request.get_json()
        search_term = data.get('search_term')

        # Searching for users matching the search term (case-insensitive)
        cur.execute("""
            SELECT email_or_phone, companion_name, username
            FROM users 
            WHERE LOWER(email_or_phone) = LOWER(%s) 
            OR LOWER(companion_name) = LOWER(%s) 
            OR LOWER(username) = LOWER(%s)
        """, (search_term, search_term, search_term))
        users = cur.fetchall()

        cur.close()
        conn.close()

        if not users:
            response = {'message': 'No users found matching the search term'}
            return jsonify(response), 404

        # Convert users data to JSON format
        users_data = []
        for user in users:
            user_data = {
                'email_or_phone': user[0],
                'companion_name': user[1],
                'username': user[2]
            }
            users_data.append(user_data)

        response = {'users': users_data}
        return jsonify(response), 200

    except Exception as e:
        response = {'error': str(e)}
        return jsonify(response), 500




if __name__ == '__main__':
    app.run(debug=True,port=4001)
