import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_restful import Api, Resource
from dotenv import load_dotenv
from googletrans import Translator

from api.upstash import MemoryManager
from api.chatgpt import LlmManager
from companion import load_companions
from ftplib import FTP
import random  # Add this import at the top of your file

import json

# Location of the data files from the TS implementation
env_file = ".env.local"

# This is the default user ID and name.
def_user_id = "local"
def_user_name = "Human"
updated = False

# load environment variables from the JavaScript .env file
config = load_dotenv(env_file)

app = Flask(__name__)
CORS(app)
api = Api(app)
FTP_HOST = "chattric.com"
FTP_USER = "synteliq@chattric.com"
FTP_PASS = "Synteliq@987"
BASE_URL = "https://chattric.com/chattric.com/synteliq/uploads/"


def load_credentials():
    with open("synteliq-c0dc6371d28f.json", "r") as file:
        credentials = json.load(file)
    return credentials


def translate_text(text, destination_language):
    translator = Translator()
    detected_lang = translator.detect(text).lang

    # Convert destination language to language code
    destination_language_code = get_language_code(destination_language)

    # If the detected language is the same as the destination language, return the text as is
    if detected_lang == destination_language_code:
        return text

    # If the text is not in English, and the destination is not English, translate to English first
    if detected_lang != 'en' and destination_language_code != 'en':
        text = translator.translate(text, src=detected_lang, dest='en').text

    # If the destination language is not the current text language, translate to the destination language
    if destination_language_code != detected_lang:
        text = translator.translate(text, src='en', dest=destination_language_code).text

    return text


def get_language_code(language_name):
    # Mapping of language names to ISO 639-1 codes
    language_codes = {
        'telugu': 'te',
        'hindi': 'hi',
        'english': 'en',
        # Add other languages as needed
    }
    return language_codes.get(language_name.lower(), 'en')


async def guess_clerk_user_id(companion):
    if os.getenv('CLERK_USER_ID'):
        return os.getenv('CLERK_USER_ID')
    else:
        id = await companion.memory.find_clerk_user_id()
        return id or def_user_id


def find_index_by_email_and_name(email, name, companions):
    for index, companion in enumerate(companions):
        if companion.isPublic:
            if companion.name == name:
                return index
        else:
            if companion.email == email and companion.name == name + email.lower():
                return index
    return None


@app.route('/chat', methods=['POST'])
async def chat():
    try:
        message = request.json['message']
        email = request.json['email']
        name = request.json['name']
        lang = request.json['lang']
        # Read list of companions from JSON file
        companions = load_companions()
        # Ask user to pick a companion and load it
        index = find_index_by_email_and_name(email, name, companions)

        companion = companions[index]

        # Initialize the companion
        companion.memory = MemoryManager(companion.name, companion.llm_name)
        companion.memory.user_id = await guess_clerk_user_id(companion)
        await companion.load()
        companion.llm = LlmManager(companion.prompt_template)

        reply = await companion.chat(message, def_user_name)
        colon_index = reply.find(':')

        if colon_index != -1:  # If colon is found
            modified_text = reply[
                            colon_index + 1:].strip()  # Extract text after colon and remove leading and trailing whitespace
        else:
            modified_text = reply

        return jsonify({'response': modified_text})

    except Exception as e:
        return jsonify({'error': str(e)}), 400


def retrieve_companion_list():
    try:
        with open('companion/companion.json', 'r') as file:
            companion_list = json.load(file)
        return companion_list
    except FileNotFoundError:
        return []


@app.route('/companions', methods=['GET'])
def get_companions():
    companions = retrieve_companion_list()
    return jsonify(companions)


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'photo' not in request.files:
        return jsonify({"error": "No photo part"}), 400

    file = request.files['photo']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    if file:
        # Generate a random number to prepend to filename
        random_number = random.randint(1000, 9999)  # Generate a four-digit random number
        filename = f"{random_number}_{file.filename}"  # Prepend the random number to the filename

        try:
            with FTP(FTP_HOST, FTP_USER, FTP_PASS) as ftp:
                # FTP session starts in the correct directory, no need to change it
                ftp.storbinary(f'STOR {filename}', file.stream)

            file_url = f'{BASE_URL}{filename}'  # Construct the full URL
            return jsonify({"message": "File successfully uploaded", "url": file_url}), 201

        except Exception as e:
            return jsonify({"error": str(e)}), 500



if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5080, debug=False, use_reloader=False)


