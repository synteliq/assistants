

from flask import Flask, request, jsonify
import psycopg2

app = Flask(__name__)

def get_db_connection():
    # Replace with your PostgreSQL connection details
    conn = psycopg2.connect(
        dbname='mobiledevarkatiss',
        user='mobiledevarkatiss',
        password='welcome1',
        host='localhost',
        port='5432'
    )
    return conn

@app.route('/api/fcm_tokens', methods=['POST'])
def add_fcm_token():
    data = request.json
    if 'userId' not in data or 'fcm_token' not in data or 'appId' not in data:
        return jsonify({'error': 'Missing required fields'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("INSERT INTO fcm_tokens (userId, fcm_token, appId) VALUES (%s, %s, %s)",
                       (data['userId'], data['fcm_token'], data['appId']))
        conn.commit()
        return jsonify({'message': 'FCM token added successfully'}), 201
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    app.run(debug=True,port=4001)
