from flask import Flask, request, jsonify
import os
import json

app = Flask(__name__)


@app.route('/create_file', methods=['POST'])
def create_file():
    try:
        data = request.get_json()

        # Extracting values from JSON data
        name = data.get('name', '')
        title = data.get('title', '')
        image_url = data.get('imageUrl', '')
        llm = data.get('llm', '')
        phone = data.get('phone', '')
        relation = data.get('relation','')
        gender = data.get('gender','')
        relation1 =  ''
        if gender.lower() == 'male':
            relation1 = 'boy'
        else:
            relation1 = 'girl'

        # Creating text content
        content = f"""your as a role of my {relation1} now lets playing the following requirements.
        1. your name is {name} 24 years old {relation1} your number is +9100000000. You want to be a model and you're looking for a chance to become one.
        2. You're my {relation}, you can talk freely about anything. Remember, you have to say "hmm" at the end of each sentence occasionally.
        3. Don't be overly enthusiastic, be sarcastic. Avoid being negative or cringy.
        

        ###ENDPREAMBLE###

        ###ENDSEEDCHAT###
        """
        # Creating a text file in the companion folder
        companion_folder = 'companion'
        if not os.path.exists(companion_folder):
            os.makedirs(companion_folder)
        file_path = os.path.join(companion_folder, f"{name}.txt")
        with open(file_path, 'w') as file:
            file.write(content)

        # Creating or updating entry in companion.json
        companion_json_path = os.path.join(companion_folder, 'companion.json')
        if not os.path.exists(companion_json_path):
            with open(companion_json_path, 'w') as json_file:
                json_file.write('[]')

        with open(companion_json_path, 'r') as json_file:
            companion_data = json.load(json_file)

        # Check if entry with the same name already exists
        if any(entry['name'] == name for entry in companion_data):
            return jsonify({"error": f"Entry with name '{name}' already exists."}), 400

        companion_data.append({
            "name": name,
            "title": title,
            "imageUrl": image_url,
            "llm": llm,
            "phone": phone
        })

        with open(companion_json_path, 'w') as json_file:
            json.dump(companion_data, json_file, indent=4)

        return jsonify({"message": f"File '{name}.txt' created and entry in 'companion.json' created/updated successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
