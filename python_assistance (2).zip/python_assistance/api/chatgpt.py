#
#  API to OpenAI's ChatGPT via LangChain
#

from langchain import LLMChain
from langchain.chat_models import ChatOpenAI


class LlmManager:
    verbose = False

    def __init__(self, prompt_template, max_response_length=100):
        self.model = ChatOpenAI(model="gpt-4o")
        self.chain = LLMChain(llm=self.model, prompt=prompt_template, verbose=self.verbose)
        self.max_response_length = max_response_length
        return
