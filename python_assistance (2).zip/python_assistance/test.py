# import requests
#
# import elevenlabs
# elevenlabs.set_api_key("a501403d9e5a452838cdeed62cee76f3")
# voice = elevenlabs.Voice(
#     voice_id="pMsXgVXv3BLzUgSXRplE",
#     settings=elevenlabs.VoiceSettings(
#         stability=0,
#         similarity_boost=0.75
#     )
# )
#
#
# audio = elevenlabs.generate(
#     text="Hi, I'm from the future!",
#     voice=voice
# )
#
# elevenlabs.play(audio)
# elevenlabs.save(audio, "audio.mp3")
import openai
# import requests
#
# url = "https://api.elevenlabs.io/v1/text-to-speech/ftDdhfYtmfGP0tFlBYA1"
#
# payload = {
#     "model_id": "eleven_multilingual_v2",
#     "text": "Hello how are you",
#     "voice_settings": {
#         "stability": 0,
#         "similarity_boost": 0.75
#     }
# }
# headers = {
#     "xi-api-key": "a501403d9e5a452838cdeed62cee76f3",
#     "Content-Type": "application/json"
# }
#
# response = requests.request("POST", url, json=payload, headers=headers)
#

import requests
from flask import Flask, request

# Set your Twilio account SID and Auth Token
account_sid = 'ACf8dd7b91e7be84ba31a4ca78b688f815'
auth_token = '3110d6719b874ac2384f1aaabfd31172'

# Set your Eleven Labs API key and URL
eleven_labs_api_key = 'a501403d9e5a452838cdeed62cee76f3'
eleven_labs_api_url = 'https://api.elevenlabs.io/v1/text-to-speech/ftDdhfYtmfGP0tFlBYA1'

# Set your OpenAI GPT API key
openai.api_key = 'your_openai_api_key'


def generate_gpt_response(prompt):
    response = openai.Completion.create(
        engine="text-davinci-002",
        prompt=prompt,
        max_tokens=150,
        n=1,
        stop=None,
        temperature=0.7,
    )
    return response.choices[0].text.strip()


def synthesize_speech_eleven_labs(text):
    payload = {
        "model_id": "eleven_multilingual_v2",
        "text": text,
        "voice_settings": {
            "stability": 0,
            "similarity_boost": 0.75
        }
    }

    headers = {
        "xi-api-key": eleven_labs_api_key,
        "Content-Type": "application/json"
    }

    response = requests.post(eleven_labs_api_url, json=payload, headers=headers)

    return response.content


if __name__ == "__main__":
    response = VoiceResponse()
    response.say("Hello! I'm ChatGPT. How can I help you today?")

    recording_url = "https://example.com/path/to/your/recording"  # Replace with the actual recording URL

    transcription = transcribe_audio(recording_url)
    gpt_response = generate_gpt_response(transcription)
    audio_content = synthesize_speech_eleven_labs(gpt_response)

    response.say(gpt_response)

    # Assuming Eleven Labs API returns audio content
    response.play(audio_content)

    print(str(response))