from jinja2 import Template
import os
import openai

# Set your actual OpenAI API key here
openai.api_key = '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'

def generate_flutter_project(project_name, chat_input):
    # Define project structure
    project_structure = {
        'lib': {
            'main.dart': '',  # Leave this empty for now
            'screens': {}
        },
        'android': {},
        'ios': {},
        'web': {}
    }

    # Generate code using ChatGPT
    generated_code = generate_code_with_chat_gpt(chat_input)

    # Modify project structure based on generated code
    project_structure['lib']['main.dart'] = generated_code

    # Create project directory
    os.mkdir(project_name)
    os.chdir(project_name)

    # Create project files and directories
    create_project_structure(project_structure)

def create_project_structure(structure):
    for item, value in structure.items():
        if isinstance(value, dict):
            os.mkdir(item)
            os.chdir(item)
            create_project_structure(value)
            os.chdir('..')
        else:
            # Create files and render templates if needed
            if value:
                with open(item, 'w') as f:
                    if item.endswith('.dart'):
                        # Use Jinja2 for template rendering
                        template = Template(value)
                        rendered_template = template.render()  # Render the template
                        f.write(rendered_template)
                    else:
                        f.write(value)

def generate_code_with_chat_gpt(chat_input):
    # Call OpenAI's completion endpoint with the provided input
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": chat_input}
        ],
        max_tokens=100,
        stream=False
    )

    # Extract and return the generated code
    generated_code = response.choices[0].message.strip()
    return generated_code

if __name__ == "__main__":
    project_name = "my_flutter_project"
    chat_input = "Generate code for a Flutter project with a sidebar menu and product listing"
    generate_flutter_project(project_name, chat_input)
