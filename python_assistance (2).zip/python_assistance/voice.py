from flask import Flask, request, Response
import requests

app = Flask(__name__)


@app.route("/voice", methods=['POST'])
def voice():
    # Respond to Twilio with instructions to gather speech input
    response = '''<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Gather input="speech" action="/handle_speech" method="POST" timeout="10" speechTimeout="auto">
        <Say>Please say your message after the beep and I will send it to the chat service.</Say>
    </Gather>
    <!-- Fallback if no speech was detected -->
    <Say>I did not receive any input. Goodbye!</Say>
</Response>'''
    return Response(response, mimetype='text/xml')


@app.route("/handle_speech", methods=['POST'])
def handle_speech():
    # Extract the transcribed text
    text = request.form.get('SpeechResult', '')
    # Prepare the data to be sent to your chat API
    data = {"message": text, "email": "gandasirimahender1@gmail.com", "name": "mahi"}
    # Send the text to your chat API
    api_response = requests.post("http://130.211.112.219:8080/chat", json=data)
    if api_response.status_code == 200:
        # Extract the response from your API
        chat_response = api_response.json().get('response', 'Sorry, I could not get a response from the chat service.')
    else:
        chat_response = 'Sorry, there was an error communicating with the chat service.'

    # Use Twilio’s <Say> to read the chat service response back to the caller
    twiml_response = f'''<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say>{chat_response}</Say>
</Response>'''
    return Response(twiml_response, mimetype='text/xml')


if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5000)
